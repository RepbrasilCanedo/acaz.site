<?php

namespace Core;

if(!defined('R8P3B1R9S6L1')){

    //header("location:/");

    die("Erro: Pagina nao encontrata");

}



echo "View da pagina erro do site carregada <br>";

