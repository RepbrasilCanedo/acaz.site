<?php

if (!defined('R8P3B1R9S6L1')) {
    header("location:/");
    die("Erro: Pagina nao encontrata");
}
?>
<body style="background: url(<?php echo URL; ?>app/sts/assets/images/Papel_Parede.jpg) left center;">
  <!-- Início do Carousel superior-->
    <section class="top-carr p-0 mt-4 w-100">
    <div class="container-fluid p-0">      
        <div class="row no-gutters">
          <div class="col-md-12 p-0">         
              <?php
              // Acessa o IF quando encontrou algum registro no banco de dados
              if (!empty($this->data['home']['carroussel'][0])) {
                  //foreach ($this->data['home']['carroussel'][0] as $home) {
                    extract($this->data['home']['carroussel'][0]);
                    //echo('<pre>');print_r($home); echo('</pre>');
              ?>          
            <div id="carousel_imagens" class="carousel slide" data-ride="carousel" >
              <!--Início inner-->
              <div class="carousel-inner">
                <div class="carousel-item">
                  <img src="<?php echo URLADM; ?>app/sts/assets/images/carrousel/<?php if (isset($image_1)) {echo $image_1;}?>" class="d-block w-100" alt="Secullum Acadêmia">
                  <div class="carousel-caption d-none d-md-block">
                    <h3 class="texto-carrousel"><?php if (isset($titlte_1)) {echo $titlte_1;}?></h3>
                    <p class="todas-maiusculas texto-carrousel"><?php if (isset($sub_title_1)) {echo $sub_title_1;}?></p>
                    <a href="<?php if (isset($link_url_1)) {echo $link_url_1;}?>" class="btn btn-sm btn-info cor-botoes button_top"><?php if (isset($link_text_1)) {echo $link_text_1;}?> </a>
                  </div>
                </div> 

                <div class="carousel-item">
                  <img src="<?php echo URLADM; ?>app/sts/assets/images/carrousel/<?php if (isset($image_2)) {echo $image_2;}?>" class="d-block w-100" alt="Secullum Acesso">
                  <div class="carousel-caption d-none d-md-block">
                    <h3 class="texto-carrousel"><?php if (isset($titlte_2)) {echo $titlte_2;}?></h3>
                    <p class="todas-maiusculas texto-carrousel"><?php if (isset($sub_title_2)) {echo $sub_title_2;}?></p>
                    <a href="<?php if (isset($link_url_2)) {echo $link_url_2;}?>" class="btn btn-sm btn-info cor-botoes button_top"><?php if (isset($link_text_2)) {echo $link_text_2;}?></a>
                  </div>
                </div>

                <div class="carousel-item">
                  <img src="<?php echo URLADM; ?>app/sts/assets/images/carrousel/<?php if (isset($image_3)) {echo $image_3;}?>" class="d-block w-100" alt="Secullum Checkin">
                  <div class="carousel-caption d-none d-md-block">
                    <h3 class="texto-carrousel"><?php if (isset($titlte_3)) {echo $titlte_3;}?></h3>
                    <p class="todas-maiusculas texto-carrousel"><?php if (isset($sub_title_3)) {echo $sub_title_3;}?></p>
                    <a href="<?php if (isset($link_url_3)) {echo $link_url_3;}?>" class="btn btn-sm btn-info cor-botoes button_top"><?php if (isset($link_text_3)) {echo $link_text_3;}?></a>
                  </div>
                </div>

                <div class="carousel-item">
                  <img src="<?php echo URLADM; ?>app/sts/assets/images/carrousel/<?php if (isset($image_4)) {echo $image_4;}?>" class="d-block w-100" alt="Secullum Estacionamento">
                  <div class="carousel-caption d-none d-md-block">
                    <h3 class="texto-carrousel"><?php if (isset($titlte_4)) {echo $titlte_4;}?></h3>
                    <p class="todas-maiusculas texto-carrousel"><?php if (isset($sub_title_4)) {echo $sub_title_4;}?></p>
                    <a href="<?php if (isset($link_url_4)) {echo $link_url_4;}?>" class="btn btn-sm btn-info cor-botoes button_top"><?php if (isset($link_text_4)) {echo $link_text_4;}?></a>
                  </div>
                </div>

                <div class="carousel-item active">
                  <img src="<?php echo URLADM; ?>app/sts/assets/images/carrousel/<?php if (isset($image_5)) {echo $image_5;}?>" class="d-block w-100" alt="Secullum Ponto">
                  <div class="carousel-caption d-none d-md-block">
                    <h3 class="texto-carrousel"><?php if (isset($titlte_5)) {echo $titlte_5;}?></h3>
                    <p class="todas-maiusculas texto-carrousel"><?php if (isset($sub_title_5)) {echo $sub_title_5;}?></p>
                    <a href="<?php if (isset($link_url_5)) {echo $link_url_5;}?>" class="btn btn-sm btn-info cor-botoes button_top"><?php if (isset($link_text_5)) {echo $link_text_5;}?></a>
                  </div>
                </div>

                <div class="carousel-item">
                  <img src="<?php echo URLADM; ?>app/sts/assets/images/carrousel/<?php if (isset($image_6)) {echo $image_6;}?>" class="d-block w-100" alt="Secullum Escola">
                  <div class="carousel-caption d-none d-md-block">
                    <h3 class="texto-carrousel"><?php if (isset($titlte_6)) {echo $titlte_6;}?></h3>
                    <p class="todas-maiusculas texto-carrousel"><?php if (isset($sub_title_6)) {echo $sub_title_6;}?></p>
                    <a href="<?php if (isset($link_url_6)) {echo $link_url_6;}?>" class="btn btn-sm btn-info cor-botoes button_top"><?php if (isset($link_text_6)) {echo $link_text_6;}?></a>
                  </div>
                </div>
              </div>
              <!--Final inner-->
              <!-- inicio controles -->
              <a href="#carousel_imagens" class="carousel-control-prev" data-slide="prev"><i class="fas fa-angle-left fa-3x"></i></a>
              <a href="#carousel_imagens" class="carousel-control-next" data-slide="next"><i class="fas fa-angle-right fa-3x"></i></a>
              <!-- Final dos controles -->
            </div>
            <!-- Final do Carousel Superior-->
            <?php
              //}
            } else {
                echo "<p style='color: #f00;'>Erro: Nenhum registro encontrado</p>";
            }
            ?>
          </div>
        </div>
      </div>
    </section>
  <!-- Final do Carousel superior-->

<div class="container max-width">

    <!--Inicio da primeira Imagens de marketing-->  
    <!--
      <section class="institucional max-width"> 
        <div class="row">
          <div class="col md-6 centralizar">
                <img src="<?php echo URLADM; ?>app/sts/assets/images/institucional/workshop_carav_cult.jpg" alt="Oficinas culturais">
          </div>
          <div class="col md-6 centralizar">
                <img src="<?php echo URLADM; ?>app/sts/assets/images/institucional/workshop_cultural.jpg" alt="Oficinas culturais">
          </div>
        </div>
      </section>
          -->
  <!--final da primeira linha de Imagens de marketing--> 

  <!--Inicio da primwira linha de textos 
  
    <div class="row mt-5">
      <div class="col-md-8">
        <?php
          if (!empty($this->data['home']['content'][0])) {
                extract($this->data['home']['content'][0]);
          ?>
        <section class="initial-article max-width centralizar mb-5">
        <article id="materia_inicial_col_esq">
            <h1 id="titulo_materia_inicial" class="conteudo-produtos centralizar"><?php if (isset($title)) {echo $title;}?></h1>
            <p class="texto-caixa"><?php if (isset($contente_1)) {echo $contente_1;}?></p>
            <p class="texto-caixa"><?php if (isset($contente_2)) {echo $contente_2;}?></p>
            <p class="texto-caixa"><?php if (isset($contente_3)) {echo $contente_3;}?></p>
            <p class="texto-caixa"><?php if (isset($contente_4)) {echo $contente_4;}?></p>
          </article>
          </section> 
          <?php
          } else {
              echo "<p style='color: #f00;'>Erro: Nenhum registro encontrado</p>";
          }
          ?>

      </div>

      <div class="col-md-4 mt-5">
            <img src="<?php echo URLADM; ?>app/sts/assets/images/institucional/oficina_2.jpg" alt="Oficinas culturais">
      </div>   
    </div>
    <div class="row">
        <div class="col-md-4 ">
          <img src="<?php echo URLADM; ?>app/sts/assets/images/institucional/oficina_3.jpg" alt="Oficinas culturais">
        </div>
        <div class="col-md-4">
          <img src="<?php echo URLADM; ?>app/sts/assets/images/institucional/oficina_5.jpg" alt="Oficinas culturais">
        </div>        
        <div class="col-md-4">
          <img src="<?php echo URLADM; ?>app/sts/assets/images/institucional/oficina_4.jpg" alt="Oficinas culturais">
        </div>
    </div>
    <div class="col centralizar mt-4">
            <img src="<?php echo URLADM; ?>app/sts/assets/images/institucional/regua_pnab.jpg" alt="Oficinas culturais">
      </div> 
final da primeira linha de textos-->  

<!--ANUNCIO EVENTOS-->  
<div class="mt-5 container centralizar text-center">
  <?php
    if (!empty($this->data['home']['evento'][0])) {
      extract($this->data['home']['evento'][0]);
  ?>
    <h2 class="fw-bold mb-4"><?php if (isset($title)) {echo $title;}?></h2>

    <div class="mb-4">
      <img src="<?php echo URLADM; ?>app/sts/assets/images/marketing/<?php if (isset($img)) {echo $img;}?>" alt="<?php if (isset($img_alt)) {echo $img_alt;}?>" class="img-fluid rounded shadow-lg w-75">
    </div>
    <p class="fs-5 fw-bold"><?php if (isset($content)) {echo $content;}?></p>

    
      <!--<video width="640" height="360" controls>
        <source src="<?php echo URL; ?>app/sts/assets/videos/home.mp4" type="video/mp4">
        Seu navegador não suporta a tag de vídeo.
      </video>--> 


  <?php
    } else {
      echo "<p style='color: #f00;'>Erro: Nenhum registro encontrado</p>";
    }
  ?>
</div>

<!--1 POST temporario-->  
    <!--Inicio da terceira linha de textos-->  
    
      <div class="row mt-5 centralizar">
      <div class="col-md-8">
        <section class="initial-article max-width centralizar mb-5">
        <article id="materia_inicial_col_esq">
            <h1 id="titulo_materia_inicial" class="conteudo-produtos centralizar">Associação de Capoeira Nação Yorubá da cidade de Una</h1><br>
            <p class="texto-caixa">Em mais um importante evento realizado pela <strong>Associação de Capoeira Nação Yorubá</strong>, na cidade de Una, a <strong>ACAZ</strong> marcou presença atendendo ao convite especial do <strong>Mestre Fábio</strong>, contribuindo para abrilhantar a cerimônia de <strong>Batizado e Troca de Cordéis</strong></p><br>
            <p class="texto-caixa">Representando nossa Associação estiveram presentes o <strong>Mestre Lucas</strong>, os maestros da <strong>Levada Percussiva</strong> — <strong>Sávio Lucas</strong> e <strong>D'Lucas</strong> — além do percussionista <strong>Pedro Lucas</strong>, que juntos levaram energia, musicalidade e envolvimento cultural ao evento, fortalecendo ainda mais os laços entre os grupos participantes.</p><br>
            <p class="texto-caixa">Durante a programação, foi realizada uma justa e emocionante homenagem aos mestres presentes, reconhecendo sua <strong>brilhante trajetória na difusão, preservação e valorização da Capoeira</strong> em nossa Bahia e em todo o Brasil. Cada homenagem reforçou a importância desses guardiões da tradição, responsáveis por manter viva a essência, a história e os valores dessa arte que atravessa gerações.</p><br>
            <p class="texto-caixa">O evento, repleto de integração, respeito e celebração, reafirma o papel fundamental da Capoeira como instrumento cultural, social e educativo, fortalecendo a união entre as comunidades e garantindo que sua memória siga viva e pulsante.</p>
          </article>
          <!--<a href="<?php if (isset($url_content)) {echo $url_content;}?>" class="btn btn-sm btn-info cor-botoes mb-5 button_top"> <?php if (isset($url_text)) {echo $url_text;}?> </a>-->
        </section> 
      </div>

      <div class="col-md-4 mt-5 ">
            <img src="<?php echo URLADM; ?>app\sts\assets\images\institucional\temp1.jpg" class="p-3" alt="Caravana Cultural">
            <img src="<?php echo URLADM; ?>app\sts\assets\images\institucional\temp2.jpg" class="p-3" alt="Caravana Cultural">
      </div>   
    </div>
    <div class="row">
        <div class="col-md-3 ">
          <img src="<?php echo URLADM; ?>app\sts\assets\images\institucional\temp3.jpg"  alt="Caravana Cultural">
        </div>
        <div class="col-md-3">
          <img src="<?php echo URLADM; ?>app\sts\assets\images\institucional\temp4.jpg" alt="Caravana Cultural">
        </div>        
        <div class="col-md-3">
          <img src="<?php echo URLADM; ?>app\sts\assets\images\institucional\temp5.jpg" alt="Caravana Cultural">
        </div>        
        <div class="col-md-3">
          <img src="<?php echo URLADM; ?>app\sts\assets\images\institucional\temp6.jpg" alt="Caravana Cultural">
        </div>
    </div>
    <div class="col centralizar mt-4">
            <img src="<?php echo URLADM; ?>app/sts/assets/images/institucional/regua_pnab.jpg" alt="Oficinas culturais">
    </div> 
    

    <!--1 POST-->  
    <!--Inicio da terceira linha de textos-->  
    
      <div class="row mt-5 centralizar">
      <div class="col-md-8">
        <?php
          if (!empty($this->data['home']['content'][0])) {
                extract($this->data['home']['content'][0]);
          ?>
        <section class="initial-article max-width centralizar mb-5">
        <article id="materia_inicial_col_esq">
            <h1 id="titulo_materia_inicial" class="conteudo-produtos centralizar"><?php if (isset($title_2)) {echo $title_2;}?></h1>
            <p class="texto-caixa"><?php if (isset($contente_5)) {echo $contente_5;}?></p>
            <p class="texto-caixa"><?php if (isset($contente_6)) {echo $contente_6;}?></p>
            <p class="texto-caixa"><?php if (isset($contente_7)) {echo $contente_7;}?></p>
            <p class="texto-caixa"><?php if (isset($contente_8)) {echo $contente_8;}?></p>
          </article>
          <!--<a href="<?php if (isset($url_content)) {echo $url_content;}?>" class="btn btn-sm btn-info cor-botoes mb-5 button_top"> <?php if (isset($url_text)) {echo $url_text;}?> </a>-->
        </section> 
          <?php
              //}
          } else {
              echo "<p style='color: #f00;'>Erro: Nenhum registro encontrado</p>";
          }
          ?>

      </div>

      <div class="col-md-4 mt-5 ">
            <img src="<?php echo URLADM; ?>app/sts/assets/images/institucional/post_2.jpg" class="p-3" alt="Caravana Cultural">
            <img src="<?php echo URLADM; ?>app/sts/assets/images/institucional/post_21.jpg" class="p-3" alt="Caravana Cultural">
      </div>   
    </div>
    <div class="row">
        <div class="col-md-3 ">
          <img src="<?php echo URLADM; ?>app/sts/assets/images/institucional/post_22.jpg"  alt="Caravana Cultural">
        </div>
        <div class="col-md-3">
          <img src="<?php echo URLADM; ?>app/sts/assets/images/institucional/post_23.jpg" alt="Caravana Cultural">
        </div>        
        <div class="col-md-3">
          <img src="<?php echo URLADM; ?>app/sts/assets/images/institucional/post_24.jpg" alt="Caravana Cultural">
        </div>        
        <div class="col-md-3">
          <img src="<?php echo URLADM; ?>app/sts/assets/images/institucional/post_25.jpg" alt="Caravana Cultural">
        </div>
    </div>
    <div class="col centralizar mt-4">
            <img src="<?php echo URLADM; ?>app/sts/assets/images/institucional/regua_pnab.jpg" alt="Oficinas culturais">
    </div> 
   
    <!--2 POST-->  
    <!--Inicio da segunda linha de textos-->  

    <div class="row mt-5">
      <div class="col-md-8">
        <?php
          if (!empty($this->data['home']['content'][0])) {
                extract($this->data['home']['content'][0]);
          ?>
        <section class="initial-article max-width centralizar mb-5">
        <article id="materia_inicial_col_esq">
            <h1 id="titulo_materia_inicial" class="conteudo-produtos centralizar mb-4"><?php if (isset($title)) {echo $title;}?></h1>
            <p class="texto-caixa"><?php if (isset($contente_1)) {echo $contente_1;}?></p>
            <p class="texto-caixa"><?php if (isset($contente_2)) {echo $contente_2;}?></p>
            <p class="texto-caixa"><?php if (isset($contente_3)) {echo $contente_3;}?></p>
            <p class="texto-caixa"><?php if (isset($contente_4)) {echo $contente_4;}?></p>
          </article>
          <!--<a href="<?php if (isset($url_content)) {echo $url_content;}?>" class="btn btn-sm btn-info cor-botoes mb-5 button_top"> <?php if (isset($url_text)) {echo $url_text;}?> </a>-->
        </section> 
          <?php
              //}
          } else {
              echo "<p style='color: #f00;'>Erro: Nenhum registro encontrado</p>";
          }
          ?>

      </div>

      <div class="col-md-4 mt-5">
            <img src="<?php echo URLADM; ?>app/sts/assets/images/institucional/post_1.jpeg" class="p-3" alt="Oficinas culturais">
            <img src="<?php echo URLADM; ?>app/sts/assets/images/institucional/post_12.jpeg" class="p-3" alt="Oficinas culturais">
      </div>   
    </div>
    <div class="row">
        <div class="col-md-4 ">
          <img src="<?php echo URLADM; ?>app/sts/assets/images/institucional/post_13.jpeg" alt="Oficinas culturais">
        </div>
        <div class="col-md-4">
          <img src="<?php echo URLADM; ?>app/sts/assets/images/institucional/post_14.jpeg" alt="Oficinas culturais">
        </div>        
        <div class="col-md-4">
          <img src="<?php echo URLADM; ?>app/sts/assets/images/institucional/post_15.jpeg" alt="Oficinas culturais">
        </div>
    </div>
    <div class="col centralizar mt-4">
      <img src="<?php echo URLADM; ?>app/sts/assets/images/institucional/regua_pnab.jpg" alt="Oficinas culturais">
    </div> 

  
  <!--final da primeira linha de video e texto--> 

   <!--final da segunda linha de textos-->  




  <!--Inicio da primeira linha de video e texto-->  
        <?php
          if (!empty($this->data['home']['institucional'][0])) {
                extract($this->data['home']['institucional'][0]);
        ?>
      <section class="institucional max-width"> 
        <div class="row">
          <div class="col md-12">
            <article id="video_2">
              <div class="video-container">
                <iframe width="453" height="255" src="<?php if (isset($url_video_2)) {echo $url_video_2;}?>" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe> </iframe>
              </div>
            </article>
          </div>
        </div>
      </section>

        <?php
            //}
        } else {
            echo "<p style='color: #f00;'>Erro: Nenhum registro encontrado</p>";   
        }
        ?>
  <!--final da primeira linha de video e texto--> 

        <section class="institucional max-width"> 
        <div class="row">
          <div class="col md-12 centralizar">
                <img src="<?php echo URLADM; ?>app/sts/assets/images/institucional/faixa_pnab.jpg" alt="Oficinas culturais">
          </div>
        </div>
      </section>
  <!--final da terceira linha de textos-->  
  <!-- Início do Carousel Turistico-->
    <section class="top-carr p-0 mt-4 w-100">
    <div class="container-fluid p-0">      
        <div class="row no-gutters">
          <div class="col-md-12 p-0">         
              <?php
              // Acessa o IF quando encontrou algum registro no banco de dados
              if (!empty($this->data['home']['carr_tour'][0])) {
                  //foreach ($this->data['home']['carroussel'][0] as $home) {
                    extract($this->data['home']['carr_tour'][0]);
                    //echo('<pre>');print_r($home); echo('</pre>');
              ?>          
            <div id="carousel_tour" class="carousel slide" data-ride="carousel" >
              <!--Início inner-->
              <div class="carousel-inner">
                <div class="carousel-item active">
                  <img src="<?php echo URLADM; ?>app/sts/assets/images/carrouseltour/<?php if (isset($image_1)) {echo $image_1;}?>" class="d-block w-100" alt="pontos touristicos de canavieiras bahia">
                  <div class="carousel-caption d-none d-md-block">
                    <h3 class="texto-carr_tour"><?php if (isset($titlte_1)) {echo $titlte_1;}?></h3>
                  </div>
                </div> 

                <div class="carousel-item">
                  <img src="<?php echo URLADM; ?>app/sts/assets/images/carrouseltour/<?php if (isset($image_2)) {echo $image_2;}?>" class="d-block w-100" alt="pontos touristicos de canavieiras bahia">
                  <div class="carousel-caption d-none d-md-block">
                    <h3 class="texto-carr_tour"><?php if (isset($titlte_2)) {echo $titlte_2;}?></h3>
                  </div>
                </div>

                <div class="carousel-item">
                  <img src="<?php echo URLADM; ?>app/sts/assets/images/carrouseltour/<?php if (isset($image_3)) {echo $image_3;}?>" class="d-block w-100" alt="pontos touristicos de canavieiras bahia">
                  <div class="carousel-caption d-none d-md-block">
                    <h3 class="texto-carr_tour"><?php if (isset($titlte_3)) {echo $titlte_3;}?></h3>
                  </div>
                </div>

                <div class="carousel-item">
                  <img src="<?php echo URLADM; ?>app/sts/assets/images/carrouseltour/<?php if (isset($image_4)) {echo $image_4;}?>" class="d-block w-100" alt="pontos touristicos de canavieiras bahia">
                  <div class="carousel-caption d-none d-md-block">
                    <h3 class="texto-carr_tour"><?php if (isset($titlte_4)) {echo $titlte_4;}?></h3>
                  </div>
                </div>

                <div class="carousel-item">
                  <img src="<?php echo URLADM; ?>app/sts/assets/images/carrouseltour/<?php if (isset($image_5)) {echo $image_5;}?>" class="d-block w-100" alt="pontos touristicos de canavieiras bahia">
                  <div class="carousel-caption d-none d-md-block">
                    <h3 class="texto-carr_tour"><?php if (isset($titlte_5)) {echo $titlte_5;}?></h3>
                  </div>
                </div>

                <div class="carousel-item">
                  <img src="<?php echo URLADM; ?>app/sts/assets/images/carrouseltour/<?php if (isset($image_6)) {echo $image_6;}?>" class="d-block w-100" alt="pontos touristicos de canavieiras bahia">
                  <div class="carousel-caption d-none d-md-block mb-2">
                    <h3 class="texto-carr_tour"><?php if (isset($titlte_6)) {echo $titlte_6;}?></h3>
                  </div>
                </div>
              </div>
              <!--Final inner-->
              <!-- inicio controles -->
              <a href="#carousel_tour" class="carousel-control-prev" data-slide="prev"><i class="fas fa-angle-left fa-3x"></i></a>
              <a href="#carousel_tour" class="carousel-control-next" data-slide="next"><i class="fas fa-angle-right fa-3x"></i></a>
              <!-- Final dos controles -->
            </div>
            <!-- Final do Carousel Superior-->
            <?php
              //}
            } else {
                echo "<p style='color: #f00;'>Erro: Nenhum registro encontrado</p>";
            }
            ?>
          </div>
        </div>
      </div>
    </section>
  <!-- Final do Carousel Turistico-->








  <!--Inicio da primeira linha de divulgações-->
    <section class="divulgacao">
      <?php
          if (!empty($this->data['home']['divulgacao'][0])) {
                extract($this->data['home']['divulgacao'][0]);
      ?> 

      <!--Inicio da segunda linha de video e texto-->  
        <div class="row">
          <div class="col centralizar md-4">
              <?php
                if (!empty($this->data['home']['institucional'][0])) {
                      extract($this->data['home']['institucional'][0]);
              ?>
            <section class="institucional max-width">        
              <article id="video">
                <div class="video-container">
                  <iframe width="453" height="255" src="<?php if (isset($url_video)) {echo $url_video;}?>" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe> </iframe>
                </div>
              </article>
            </section>
              <?php
                  //}
              } else {
                  echo "<p style='color: #f00;'>Erro: Nenhum registro encontrado</p>";   
              }
              ?>        
          </div>
        </div>
      <!--final da segunda linha de video e texto--> 

      <div class="row mt-3">
        <!-- Divulgação primeira linha  coluna esquerda -->
        <div class="col-md-4  p-2" style="text-align:center;">
          <h5 class="conteudo-produtos"><?php if (isset($title_img_1)) {echo $title_img_1;}?></h5>
          <a href="<?php if (isset($url_image_1)) {echo $url_image_1;}?>" class="navbar-brand">
            <img src="<?php echo URLADM; ?>app/sts/assets/images/institucional/<?php if (isset($image_1)) {echo $image_1;}?>" alt="<?php if (isset($image_1_alt)) {echo $image_1_alt;}?>" title="<?php if (isset($image_1_title)) {echo $image_1_title;}?>">
          </a>
        </div>

        <!-- Divulgação primeira linha  coluna centro -->
        <div class="col-md-4  p-2" style="text-align:center;">
          <h5 class="conteudo-produtos"><?php if (isset($title_img_2)) {echo $title_img_2;}?></h5>
          <a href="<?php if (isset($url_image_2)) {echo $url_image_2;}?>" class="navbar-brand">
            <img src="<?php echo URLADM; ?>app/sts/assets/images/institucional/<?php if (isset($image_2)) {echo $image_2;}?>" alt="<?php if (isset($image_2_alt)) {echo $image_2_alt;}?>" title="<?php if (isset($image_2_title)) {echo $image_2_title;}?>">
          </a>
        </div>

        <!-- Divulgação primeira linha  coluna direita -->
        <div class="col-md-4  p-2" style="text-align:center;">
          <h5 class="conteudo-produtos"><?php if (isset($title_img_3)) {echo $title_img_3;}?></h5>
          <a href="<?php if (isset($url_image_3)) {echo $url_image_3;}?>" class="navbar-brand">
            <img src="<?php echo URLADM; ?>app/sts/assets/images/institucional/<?php if (isset($image_3)) {echo $image_3;}?>" alt="<?php if (isset($image_3_alt)) {echo $image_3_alt;}?>" title="<?php if (isset($image_3_title)) {echo $image_3_title;}?>">
          </a>
        </div>
      </div>

      <div class="row mt-3">
        <!-- Divulgação segunda linha  coluna esquerda -->
        <div class="col-md-4  p-2" style="text-align:center;">
          <h5 class="conteudo-produtos"><?php if (isset($title_img_4)) {echo $title_img_4;}?></h5>
          <a href="<?php if (isset($url_image_4)) {echo $url_image_4;}?>" class="navbar-brand">
            <img src="<?php echo URLADM; ?>app/sts/assets/images/institucional/<?php if (isset($image_4)) {echo $image_4;}?>" alt="<?php if (isset($image_4_alt)) {echo $image_4_alt;}?>" title="<?php if (isset($image_3_title)) {echo $image_3_title;}?>">
          </a>
        </div>

        <!-- Divulgação segunda linha  coluna centro -->
        <div class="col-md-4  p-2" style="text-align:center;">
          <h5 class="conteudo-produtos"><?php if (isset($title_img_5)) {echo $title_img_5;}?></h5>
          <a href="<?php if (isset($url_image_5)) {echo $url_image_5;}?>" class="navbar-brand">
            <img src="<?php echo URLADM; ?>app/sts/assets/images/institucional/<?php if (isset($image_5)) {echo $image_5;}?>" alt="<?php if (isset($image_5_alt)) {echo $image_5_alt;}?>" title="<?php if (isset($image_5_title)) {echo $image_5_title;}?>">
          </a>
        </div>

        <!-- Divulgação segunda linha  coluna direita -->
        <div class="col-md-4  p-2" style="text-align:center;">
          <h5 class="conteudo-produtos"><?php if (isset($title_img_6)) {echo $title_img_6;}?></h5>
          <a href="<?php if (isset($url_image_6)) {echo $url_image_6;}?>" class="navbar-brand">
            <img src="<?php echo URLADM; ?>app/sts/assets/images/institucional/<?php if (isset($image_6)) {echo $image_6;}?>" alt="<?php if (isset($image_6_alt)) {echo $image_6_alt;}?>" title="<?php if (isset($image_6_title)) {echo $image_6_title;}?>">
          </a>
        </div>
      </div>
    </section>

  <div style="text-align:center;">
            <a href="index.php" class="btn btn-sm btn-info cor-botoes mb-5 button_top" > Topo da Página </a>
    </div> 
        <?php
            //}
        } else {
            echo "<p style='color: #f00;'>Erro: Nenhum registro encontrado</p>";   
        }
        ?>
        <div class="row">
          <div class="col" style="text-align:center;">
            <img src="<?php echo URLADM; ?>app/sts/assets/images/institucional/regua_pnab.jpg">
          </div>
        </div>
</div>
</body>



